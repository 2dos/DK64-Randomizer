TEST_MODULE_URL = (
    "https://raw.githubusercontent.com/ryanking13/pyodide-importer/main/test_modules/"
)
