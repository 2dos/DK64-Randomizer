from .otBase import BaseTTXConverter


class table_V_V_A_R_(BaseTTXConverter):
	pass
