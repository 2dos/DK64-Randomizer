"""Version of pillow_heif/pi_heif."""

__version__ = "1.0.0"
